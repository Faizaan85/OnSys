<?php $this->load->view('common/js'); ?>
</div>
    </body>
</html>