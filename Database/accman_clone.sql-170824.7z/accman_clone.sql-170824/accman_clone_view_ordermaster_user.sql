
-- --------------------------------------------------------

--
-- Structure for view `ordermaster_user`
--
DROP TABLE IF EXISTS `ordermaster_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ordermaster_user`  AS  select `a`.`OmId` AS `OmId`,`a`.`OmCompanyName` AS `OmCompanyName`,`a`.`OmCreatedOn` AS `OmCreatedOn`,`a`.`OmLpo` AS `OmLpo`,`a`.`OmStatus` AS `OmStatus`,`a`.`OmStore1` AS `OmStore1`,`a`.`OmStore2` AS `OmStore2`,`a`.`OmPrinted` AS `OmPrinted`,`b`.`UsrName` AS `OmCreatedBy` from (`ordermaster` `a` join `users` `b`) where ((`a`.`OmCreatedBy` = `b`.`UsrId`) and (`a`.`OmIsDeleted` = 0)) ;
