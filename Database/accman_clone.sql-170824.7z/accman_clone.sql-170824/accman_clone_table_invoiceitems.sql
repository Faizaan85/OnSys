
-- --------------------------------------------------------

--
-- Table structure for table `invoiceitems`
--

DROP TABLE IF EXISTS `invoiceitems`;
CREATE TABLE IF NOT EXISTS `invoiceitems` (
  `IiId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ImId` int(10) UNSIGNED NOT NULL,
  `IiPartNo` varchar(15) NOT NULL,
  `IiSupplierNo` varchar(15) DEFAULT NULL COMMENT 'allowed null cause of MI999',
  `IiDescription` varchar(150) DEFAULT NULL COMMENT 'allowed null cause of MI999',
  `IiLeftQty` int(11) NOT NULL DEFAULT '0',
  `IiRightQty` int(11) NOT NULL DEFAULT '0',
  `IiTotalQty` int(11) NOT NULL,
  `IiPrice` decimal(10,2) NOT NULL,
  `IiAmount` decimal(11,2) NOT NULL,
  `IiCreatedOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IiModifiedOn` timestamp NULL DEFAULT NULL,
  `IiIsDelete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IiId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
