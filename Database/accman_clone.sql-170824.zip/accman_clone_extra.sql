
--
-- Constraints for dumped tables
--

--
-- Constraints for table `itemdetails`
--
ALTER TABLE `itemdetails`
  ADD CONSTRAINT `Fkey_ParNo` FOREIGN KEY (`IdIPART_NO`) REFERENCES `item` (`PART_NO`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD CONSTRAINT `Fkey_OmId` FOREIGN KEY (`OiOmId`) REFERENCES `ordermaster` (`OmId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ordermaster`
--
ALTER TABLE `ordermaster`
  ADD CONSTRAINT `FkeyUser` FOREIGN KEY (`OmCreatedBy`) REFERENCES `users` (`UsrId`);
