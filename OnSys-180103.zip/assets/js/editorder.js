$(document).ready(function()
{   var order_id ;
	if($global_mode == "Edit"){
		$('#date_created').attr("disabled","disabled");
		var duedate = getDueDate('date_created','#term_pay');
    	$('#due_date').val(duedate);
    	order_id = $('#order_num').val();
		// $('#date_created').attr()
		calculateNetAmount();
	}
	$('#term_pay').on('change', function(){
		$('#due_date').val(getDueDate('date_created','#term_pay'));
	});

	//toggle forms: make creating order more visible
    $('#open-close-toggle').on('click',function(){
        //#toggle-section is the Element to Toggle
        //.toggle-section is the up-down arrow image to toggle.
        $('#toggle-section').slideToggle(function() {
            $('.toggle-section').toggle();
        });
    });

    //make invoie. this is gonna be another problematic code.
    $('#make_invoice').on('click',function(){
    	//first, I need to check if the Order has been saved. 
    	//To check that, I can check if #order_num has value set to it.
    	console.log("clicked");
    	if(order_id == ""){
    		//This means order is not saved yet. 
    		//show msge to user to save the order first.
    		
    		//this is cause i dont have time to trigger the event myself and
    		//get the order_id myself cause i don't know how long it will take before click even is complete.
    		
    		// $('#save').trigger('click');
    		alert("Please save the order first");
    	}else{
    		//this means order_id is set.
    		//now i need to use this number to make invoice

    		console.log("ajax starting");
    		$.ajax({
    			url: $base_url+'orders/make_invoice',
    			type: 'POST',
    			dataType: 'json',
    			data: {
    				order_id: order_id,
    				vat_percent: $('#vat').attr('data-vat-val'),
    				due_date: $('#due_date').val(),
    				username: $('#username').attr("data-username")
    			},
    		success: function(res)
	        {
				// #something is a Div. so i will append the order number.
				$('#inv_num').val(res);
				$(this).attr('disabled','disabled');
	            console.log(res);
	        },
	        error: function(request, status, error)
	        {
	        	//need to flash msg to notify error.
	        	//need to enable save button again.
	        	console.log("error: ");
	        	console.log(request.responseText);
	        	$(this).removeAttr("disabled");

	        }});
    		
    		
    	}
    });
});