<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-19 08:39:08 --> 404 Page Not Found: 
ERROR - 2017-09-19 08:39:10 --> 404 Page Not Found: 
ERROR - 2017-09-19 08:39:12 --> 404 Page Not Found: 
ERROR - 2017-09-19 08:39:39 --> 404 Page Not Found: 
