<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-13 08:32:22 --> Query error: Column 'OmCompanyName' cannot be null - Invalid query: INSERT INTO `ordermaster` (`OmCompanyName`, `OmCreatedOn`, `OmLpo`) VALUES (NULL, NULL, NULL)
ERROR - 2017-04-13 08:38:37 --> Query error: Column 'OmCompanyName' cannot be null - Invalid query: INSERT INTO `ordermaster` (`OmCompanyName`, `OmCreatedOn`, `OmLpo`) VALUES (NULL, NULL, NULL)
ERROR - 2017-04-13 08:42:51 --> Query error: Column 'OmCompanyName' cannot be null - Invalid query: INSERT INTO `ordermaster` (`OmCompanyName`, `OmCreatedOn`, `OmLpo`) VALUES (NULL, NULL, NULL)
ERROR - 2017-04-13 08:47:47 --> Query error: Column 'OmCompanyName' cannot be null - Invalid query: INSERT INTO `ordermaster` (`OmCompanyName`, `OmCreatedOn`, `OmLpo`) VALUES (NULL, NULL, NULL)
ERROR - 2017-04-13 08:59:40 --> 404 Page Not Found: ONsYS/NEWORDER
ERROR - 2017-04-13 10:00:55 --> Severity: Parsing Error --> syntax error, unexpected 'orderinfo' (T_STRING), expecting ',' or ';' H:\XAMPP\htdocs\OnSys\application\views\pages\order_print.php 13
