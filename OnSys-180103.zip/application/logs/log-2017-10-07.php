<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-07 10:50:43 --> 404 Page Not Found: 
