<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 8
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 8
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 11
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 16
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 19
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 22
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 30
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 31
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 33
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: orderinfo H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 34
ERROR - 2017-05-20 16:41:35 --> Severity: Notice --> Undefined variable: items H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 51
ERROR - 2017-05-20 16:41:35 --> Severity: Warning --> Invalid argument supplied for foreach() H:\XAMPP\htdocs\OnSys\application\views\pages\order.php 51
