<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-27 11:35:09 --> 404 Page Not Found: 
