<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-09 17:59:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-10-09 17:59:14 --> Unable to connect to the database
