<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-29 14:30:40 --> 404 Page Not Found: 
ERROR - 2017-04-29 14:30:53 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 27
ERROR - 2017-04-29 14:31:44 --> Severity: Parsing Error --> syntax error, unexpected '=' H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
ERROR - 2017-04-29 14:31:45 --> Severity: Parsing Error --> syntax error, unexpected '=' H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
ERROR - 2017-04-29 14:31:45 --> Severity: Parsing Error --> syntax error, unexpected '=' H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
ERROR - 2017-04-29 14:31:48 --> Severity: Parsing Error --> syntax error, unexpected '=' H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
ERROR - 2017-04-29 14:32:12 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
ERROR - 2017-04-29 14:32:13 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
ERROR - 2017-04-29 14:32:14 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
ERROR - 2017-04-29 14:32:25 --> Severity: Parsing Error --> syntax error, unexpected '=' H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:32:26 --> Severity: Parsing Error --> syntax error, unexpected '=' H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:32:27 --> Severity: Parsing Error --> syntax error, unexpected '=' H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:32:52 --> Severity: Notice --> Undefined variable: Amount H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 26
ERROR - 2017-04-29 14:32:52 --> Severity: Notice --> Undefined index: QiTotalQty H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:33:14 --> Severity: Notice --> Undefined variable: Amount H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 26
ERROR - 2017-04-29 14:33:14 --> Severity: Notice --> Undefined index: QiTotalQty H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:33:15 --> Severity: Notice --> Undefined variable: Amount H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 26
ERROR - 2017-04-29 14:33:15 --> Severity: Notice --> Undefined index: QiTotalQty H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:33:17 --> Severity: Notice --> Undefined variable: Amount H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 26
ERROR - 2017-04-29 14:33:17 --> Severity: Notice --> Undefined index: QiTotalQty H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:33:21 --> Severity: Notice --> Undefined variable: Amount H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 26
ERROR - 2017-04-29 14:33:21 --> Severity: Notice --> Undefined index: QiTotalQty H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:33:36 --> Severity: Notice --> Undefined variable: Amount H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 26
ERROR - 2017-04-29 14:33:36 --> Severity: Notice --> Undefined index: QiTotalQty H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 75
ERROR - 2017-04-29 14:34:09 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) H:\XAMPP\htdocs\GitOnSys\application\views\pages\order_print.php 23
