<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-04 15:55:34 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:55:38 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:55:50 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:56:03 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:56:07 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:56:12 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:56:17 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:56:29 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:56:38 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 15:56:47 --> Query error: Unknown column '17/05/03' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `17/05/03` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:05:34 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:06:57 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:07:04 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:07:29 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:08:13 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:08:23 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:08:33 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:08:37 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:08:47 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 16:08:57 --> Query error: Unknown column '2017-05-02' in 'where clause' - Invalid query: SELECT *
FROM `ordermaster_user`
WHERE `OmCreatedOn` > `2017-05-02` OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-05-04 17:26:26 --> Severity: Parsing Error --> syntax error, unexpected '*' H:\XAMPP\htdocs\GitOnSys\application\views\templates\header.php 74
