<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-15 08:35:25 --> 404 Page Not Found: 
