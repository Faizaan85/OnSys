<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-18 21:48:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-10-18 21:48:32 --> Unable to connect to the database
