<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-13 17:47:58 --> Severity: Parsing Error --> syntax error, unexpected '$yesterday' (T_VARIABLE) H:\XAMPP\htdocs\GitOnSys\application\models\Order_model.php 14
