<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-15 06:00:16 --> 404 Page Not Found: 
ERROR - 2017-11-15 06:00:23 --> 404 Page Not Found: 
ERROR - 2017-11-15 06:00:24 --> 404 Page Not Found: 
ERROR - 2017-11-15 06:00:24 --> 404 Page Not Found: 
ERROR - 2017-11-15 06:00:25 --> 404 Page Not Found: 
ERROR - 2017-11-15 14:10:32 --> 404 Page Not Found: Order/12816
ERROR - 2017-11-15 16:55:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-15 16:55:38 --> Unable to connect to the database
