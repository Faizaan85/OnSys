<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-06 09:14:25 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\GitOnSys\application\views\pages\neworder_view.php 15
ERROR - 2017-05-06 09:14:40 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\GitOnSys\application\views\pages\neworder_view.php 15
ERROR - 2017-05-06 09:14:47 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\GitOnSys\application\views\pages\neworder_view.php 15
ERROR - 2017-05-06 09:15:18 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\GitOnSys\application\views\pages\neworder_view.php 15
