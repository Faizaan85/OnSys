<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-20 10:40:26 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-20 10:40:26 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-20 10:42:51 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-20 10:42:51 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-20 10:43:14 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-20 10:43:14 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-20 10:43:25 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:43:26 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:43:27 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:43:27 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:47:56 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:49:07 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:49:10 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:49:16 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:49:18 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:49:21 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:50:12 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:50:13 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:50:13 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:50:13 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:50:25 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 19
ERROR - 2017-04-20 10:51:53 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 17
ERROR - 2017-04-20 10:51:53 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 29
ERROR - 2017-04-20 10:52:12 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 17
ERROR - 2017-04-20 10:52:12 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 29
ERROR - 2017-04-20 10:54:29 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 10:54:48 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 30
ERROR - 2017-04-20 10:56:55 --> Severity: Parsing Error --> syntax error, unexpected '<' H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 10:57:21 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 30
ERROR - 2017-04-20 11:00:41 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:00 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:02 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:02 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:03 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:04 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:04 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:05 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:06 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:01:07 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 20
ERROR - 2017-04-20 11:16:18 --> 404 Page Not Found: 
ERROR - 2017-04-20 11:23:00 --> Severity: Notice --> Undefined variable: base_url H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 26
ERROR - 2017-04-20 11:23:00 --> Severity: Error --> Function name must be a string H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 26
ERROR - 2017-04-20 11:26:20 --> 404 Page Not Found: 
