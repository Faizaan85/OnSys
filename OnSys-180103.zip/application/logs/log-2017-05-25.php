<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-25 18:01:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-05-25 18:01:29 --> Unable to connect to the database
