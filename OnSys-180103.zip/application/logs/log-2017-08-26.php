<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-26 10:20:10 --> 404 Page Not Found: 
