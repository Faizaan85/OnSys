<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-15 16:45:30 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-15 16:45:30 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
