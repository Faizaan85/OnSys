<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-22 05:56:39 --> 404 Page Not Found: 
ERROR - 2017-11-22 08:43:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:28 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:28 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:30 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:31 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:31 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:32 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:33 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:42 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:48 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:49 --> Unable to connect to the database
ERROR - 2017-11-22 08:43:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:43:50 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:05 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:05 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:05 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:07 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:08 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:09 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:09 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:10 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:10 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:10 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:10 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:10 --> Unable to connect to the database
ERROR - 2017-11-22 08:44:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:44:11 --> Unable to connect to the database
ERROR - 2017-11-22 08:45:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:45:31 --> Unable to connect to the database
ERROR - 2017-11-22 08:45:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:45:32 --> Unable to connect to the database
ERROR - 2017-11-22 08:45:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:45:34 --> Unable to connect to the database
ERROR - 2017-11-22 08:45:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:45:39 --> Unable to connect to the database
ERROR - 2017-11-22 08:45:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:45:44 --> Unable to connect to the database
ERROR - 2017-11-22 08:45:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:45:59 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:12 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:12 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:13 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:13 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:13 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:20 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:27 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:33 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:39 --> Unable to connect to the database
ERROR - 2017-11-22 08:46:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:46:54 --> Unable to connect to the database
ERROR - 2017-11-22 08:47:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:47:00 --> Unable to connect to the database
ERROR - 2017-11-22 08:47:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-22 08:47:21 --> Unable to connect to the database
