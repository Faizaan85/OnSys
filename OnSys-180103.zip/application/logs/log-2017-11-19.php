<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-19 15:54:21 --> 404 Page Not Found: 
