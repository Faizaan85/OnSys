<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-11 15:40:09 --> 404 Page Not Found: 
ERROR - 2017-09-11 16:36:26 --> 404 Page Not Found: 
ERROR - 2017-09-11 16:36:28 --> 404 Page Not Found: 
