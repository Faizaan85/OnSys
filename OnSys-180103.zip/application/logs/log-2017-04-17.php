<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-17 08:06:44 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-17 08:06:44 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-17 10:28:15 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-17 10:28:15 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-17 10:29:38 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-17 10:29:38 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-17 10:30:48 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-17 10:30:48 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-17 11:38:19 --> 404 Page Not Found: 
ERROR - 2017-04-17 15:13:46 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-17 15:13:46 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-17 15:16:49 --> Severity: Notice --> Undefined variable: autorefresh H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 14
ERROR - 2017-04-17 15:16:49 --> Severity: Notice --> Undefined variable: js H:\XAMPP\htdocs\OnSys\application\views\templates\header.php 23
ERROR - 2017-04-17 15:35:17 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) H:\XAMPP\htdocs\OnSys\application\controllers\Orders.php 75
ERROR - 2017-04-17 16:22:11 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) H:\XAMPP\htdocs\OnSys\application\controllers\Orders.php 75
ERROR - 2017-04-17 16:25:51 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) H:\XAMPP\htdocs\OnSys\application\controllers\Orders.php 79
ERROR - 2017-04-17 16:26:57 --> Severity: Parsing Error --> syntax error, unexpected '{' H:\XAMPP\htdocs\OnSys\application\controllers\Orders.php 79
