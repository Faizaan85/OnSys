<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-12 17:47:29 --> 404 Page Not Found: 
ERROR - 2017-09-12 17:47:42 --> 404 Page Not Found: 
ERROR - 2017-09-12 17:47:57 --> 404 Page Not Found: 
