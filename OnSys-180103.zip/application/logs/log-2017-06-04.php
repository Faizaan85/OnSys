<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-04 08:14:21 --> 404 Page Not Found: Print/2331
ERROR - 2017-06-04 08:42:04 --> 404 Page Not Found: Print/2348
