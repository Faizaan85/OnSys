<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-14 08:22:25 --> 404 Page Not Found: 
ERROR - 2017-09-14 08:22:37 --> 404 Page Not Found: 
ERROR - 2017-09-14 08:22:58 --> 404 Page Not Found: 
ERROR - 2017-09-14 08:23:04 --> 404 Page Not Found: 
ERROR - 2017-09-14 08:23:19 --> 404 Page Not Found: 
ERROR - 2017-09-14 08:23:47 --> 404 Page Not Found: 
ERROR - 2017-09-14 08:23:51 --> 404 Page Not Found: 
ERROR - 2017-09-14 08:59:18 --> 404 Page Not Found: 
ERROR - 2017-09-14 16:39:37 --> 404 Page Not Found: 
ERROR - 2017-09-14 16:39:40 --> 404 Page Not Found: 
