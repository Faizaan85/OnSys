<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-22 09:56:48 --> Query error: Duplicate entry 'faizaan85' for key 'usr_username' - Invalid query: INSERT INTO `users` (`UsrName`, `UsrEmail`, `UsrUsername`, `UsrPassword`) VALUES ('faizaan varteji', 'faizaan.varteji@gmail.com', 'faizaan85', '202cb962ac59075b964b07152d234b70')
ERROR - 2017-04-22 10:14:26 --> Could not find the language line "form_validation_check_username"
ERROR - 2017-04-22 10:58:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`accman_clone`.`ordermaster`, CONSTRAINT `fkey_userid` FOREIGN KEY (`OmCreatedBy`) REFERENCES `users` (`UsrId`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `ordermaster` (`OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmCreatedBy`) VALUES ('OMAN AUTO PARTS', '2017-04-22', '', 0)
ERROR - 2017-04-22 11:17:29 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\OnSys\application\controllers\Orders.php 60
ERROR - 2017-04-22 11:18:55 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\OnSys\application\controllers\Orders.php 60
ERROR - 2017-04-22 11:26:28 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `ordermaster` (`OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmCreatedBy`) VALUES ('MR. WALEED OMAN', '2017-04-22', '', '3')
