<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-02 16:52:46 --> Severity: Error --> Call to undefined function where() H:\XAMPP\htdocs\GitOnSys\application\models\Order_model.php 77
ERROR - 2017-05-02 16:55:53 --> Severity: Error --> Call to undefined function where() H:\XAMPP\htdocs\GitOnSys\application\models\Order_model.php 77
