<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-24 09:39:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:39:00 --> Unable to connect to the database
ERROR - 2017-08-24 09:39:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:39:03 --> Unable to connect to the database
ERROR - 2017-08-24 09:39:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:39:05 --> Unable to connect to the database
ERROR - 2017-08-24 09:39:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:39:05 --> Unable to connect to the database
ERROR - 2017-08-24 09:39:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:39:06 --> Unable to connect to the database
ERROR - 2017-08-24 09:40:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:40:12 --> Unable to connect to the database
ERROR - 2017-08-24 09:40:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:40:12 --> Unable to connect to the database
ERROR - 2017-08-24 09:40:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:40:33 --> Unable to connect to the database
ERROR - 2017-08-24 09:40:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:40:38 --> Unable to connect to the database
ERROR - 2017-08-24 09:40:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:40:45 --> Unable to connect to the database
ERROR - 2017-08-24 09:40:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1862): Your password has expired. To log in you must change it using a client that supports expired passwords. H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-24 09:40:55 --> Unable to connect to the database
ERROR - 2017-08-24 10:44:24 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:44:26 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:44:29 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:44:30 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:44:33 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:44:33 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:44:43 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:44:52 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:04 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:07 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:15 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:17 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:33 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:47 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:48 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:45:58 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:46:14 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:46:24 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:46:37 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:46:47 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:46:51 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:47:05 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:47:13 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:47:18 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:47:30 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:47:33 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:47:42 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:48:39 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
ERROR - 2017-08-24 10:49:11 --> Query error: Table 'accman_clone.ordermaster_user' doesn't exist - Invalid query: SELECT `OmId`, `OmCompanyName`, `OmCreatedOn`, `OmLpo`, `OmStatus`, `OmStore1`, `OmStore2`, `OmPrinted`, `OmCreatedBy`
FROM `ordermaster_user`
WHERE `OmCreatedOn` > '2017-08-22' OR `OmPrinted` =0
ORDER BY `OmId` DESC
