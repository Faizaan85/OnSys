<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-18 16:06:39 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Benchmark.php 72
ERROR - 2017-05-18 16:06:39 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Benchmark.php 72
ERROR - 2017-05-18 16:06:39 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Benchmark.php 72
ERROR - 2017-05-18 16:06:39 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Benchmark.php 72
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 17:00:46 --> Severity: Error --> Maximum execution time of 30 seconds exceeded H:\XAMPP\htdocs\OnSys\system\core\Log.php 131
ERROR - 2017-05-18 18:34:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 H:\XAMPP\htdocs\OnSys\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-05-18 18:34:47 --> Unable to connect to the database
