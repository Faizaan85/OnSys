<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-03 15:20:42 --> 404 Page Not Found: 
