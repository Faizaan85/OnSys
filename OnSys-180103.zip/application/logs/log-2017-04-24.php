<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-24 11:01:02 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:01:02 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:05:58 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:05:58 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:01 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:01 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:03 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:03 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:04 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:04 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:07 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:07 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:10 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:10 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:11 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:11 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:12 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:12 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:06:57 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:06:57 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:07:03 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:07:03 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
ERROR - 2017-04-24 11:07:09 --> Severity: Warning --> Missing argument 1 for Items::get_part_details() H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 9
ERROR - 2017-04-24 11:07:09 --> Severity: Notice --> Undefined variable: partno H:\XAMPP\htdocs\OnSys1\application\controllers\Items.php 12
