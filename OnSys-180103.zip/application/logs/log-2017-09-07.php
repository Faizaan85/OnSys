<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-07 17:15:43 --> 404 Page Not Found: 
ERROR - 2017-09-07 17:15:47 --> 404 Page Not Found: 
