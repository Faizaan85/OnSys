<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-14 13:41:53 --> Severity: Notice --> Undefined variable: omId H:\XAMPP\htdocs\GitOnSys\application\models\Order_model.php 82
ERROR - 2017-05-14 13:46:55 --> Severity: Notice --> Undefined variable: omId H:\XAMPP\htdocs\GitOnSys\application\models\Order_model.php 82
ERROR - 2017-05-14 13:47:41 --> Severity: Notice --> Undefined variable: omId H:\XAMPP\htdocs\GitOnSys\application\models\Order_model.php 82
