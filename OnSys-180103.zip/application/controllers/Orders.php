<?php
require(APPPATH.'libraries/fpdf/fpdf.php');
class PDF extends FPDF
{
	// Page header
	var $oinfo;
	var $pdf_type;
	function setRows($data)
	{
		$this->oinfo = $data;
		// $this->$pdf_type = $pdftype;
	}
	function Header()
	{
		// $this->SetFont('Times','BU',16);
		// if($pdf_type == "order"){
		//     // Logo
		//     //$this->Image('logo.png',10,6,30);
		//     // Arial bold 15
		    
		//     // Move to the right
		//     //$this->Cell(80);
		// 	$this->Cell(100,10,'Order #: '.$this->oinfo['OmId'],1,0);
		// 	$this->SetFont('Times','',12);
		// 	$this->Cell(70,10,'Date: '.date("d-m-Y",strtotime($this->oinfo['OmCreatedOn'])),1,1);
		// 	$this->MultiCell(170,10,'Name: '.$this->oinfo['OmCompanyName'],1);
		// 	$this->Cell(70,10,'LPO: '.$this->oinfo['OmLpo'],1,0,'L');
		// 	$this->Cell(100,10,'Salesman: '.$this->oinfo['OmCreatedBy'],1,1);
		// 	// Line break
		//     $this->Ln(5);
		// }elseif ($pdf_type == "invoice") {
			
			//row 1
			$this->SetFont('Times','',10);
			$this->Cell(100,5,"VAT Number: 100019982600003",0,1,'R');
			$this->SetFont('Times','BU',16);
			$this->Cell(100,5,"Tax Invoice",0,1,'C');

			$this->SetFont('Times','',10);
			//row2
			$this->Cell(70,5,'Customer Details',0,0,'L');
			$this->Cell(15,5,'Invoice #',0,0,'C');
			$this->Cell(15,5,'Date',0,1,'C');

			//row3
			$this->Cell(10,5,'Customer Name',0,0,'L');
			$this->Cell(60,5,$this->oinfo['InOmCompanyName'],0,0,'C');
			$this->Cell(15,5,$this->oinfo['InId'],0,0,'C');
			$this->Cell(15,5,$this->oinfo['InCreatedOn'],0,1,'C');

			//row4
			$this->Cell(10,5,'Address',0,0,'L');
			$this->Cell(60,5,$this->oinfo['InOmAdd'],0,0,'C');
			$this->Cell(15,5,'Customer ID',0,0,'C');
			$this->Cell(15,5,'Due Date',0,1,'C');

			//row5
			$this->Cell(10,5,'Phone',0,0,'L');
			$this->Cell(60,5,$this->oinfo['InOmTel1'],0,0,'C');
			$this->Cell(15,5,$this->oinfo['InOmCompanyCode'],0,0,'C');
			$this->Cell(15,5,$this->oinfo['inDueDate'],0,1,'C');

			//row6
			$this->Cell(10,5,'Phone 2',0,0,'L');
			$this->Cell(60,5,$this->oinfo['InOmTel2'],0,0,'C');
			$this->Cell(30,5,'VAT Registration #',0,1,'C');
			
			//row7
			$this->Cell(70,5,'',0,0);
			$this->Cell(30,5,$this->oinfo['ClVatNo'],0,1,'C');

			//row8 table column header

			$this->cell(10,5,'No.',1,0,'C'); //sr no
			$this->cell(20,5,'Part No',1,0,'C'); //part no
			$this->cell(25,5,'Description',1,0,'C'); //description
			$this->cell(40,5,'Left Qty',1,0,'C'); //left qty
			$this->cell(15,5,'Right Qty',1,0,'C'); //right qty
			$this->cell(15,5,'Total Qty',1,0,'C'); //total qty
			$this->cell(15,5,'Price',1,0,'C'); //price
			$this->cell(15,5,'Amount',1,1,'C'); //amount
			// $this->cell(); //

		// }
	}
	function FancyTable($rows)
	{

	    // Colors, line width and bold font
		$this->SetFillColor(255,255,255);
	    // $this->SetTextColor(255);
	    //$this->SetDrawColor(128,0,0);
	    //$this->SetLineWidth(.3);
	    $this->SetFont('Times','B',10);
	    // Header
		//$header = array("Sr #", "Part #", "Supplier #", "Description", "R-Qty", "L-Qty", "T-Qty","Price","Amount");
	    $headerwidth = array(10, 20, 25, 40, 15, 15, 15,15,15);

	    //for($i=0;$i<count($header);$i++)
	    //    $this->Cell($headerwidth[$i],10,$header[$i],1,0,'C',true);
	     ////$this->Ln();
	    
	    // Color and font restoration
	    //$this->SetFillColor(78, 77, 79);
	    // $this->SetTextColor(0);
	    // $this->SetFont('');
	    // Data
		$this->SetFillColor(217,217,217);
	    $fill = false; // Flag
		$rc = 1; // RowCount
		$totalAmount = 0.00; //Total Counter
		$this->SetFont('Times','',10);
	    foreach($rows as $row)
	    {
			// Cell(float w [, float h [, string txt [, mixed border [, int ln [, string align [, boolean fill [, mixed link]]]]]]])
			$amount = number_format(($row['IiOiPrice'] * $row['IiOiTotalQty']), 2, '.', '');
	        $this->Cell($headerwidth[0],6,$rc,1,0,'L',$fill);
	        $this->Cell($headerwidth[1],6,$row['IiOiPartNo'],1,0,'L',$fill);
			$this->SetFontSize(6);
			$this->Cell($headerwidth[2],6,$row['IiOiSupplierNo'],1,0,'L',$fill);
			$this->Cell($headerwidth[3],6,$row['IiOiDescription'],1,0,'L',$fill);
			$this->SetFontSize(10);
			$this->Cell($headerwidth[4],6,$row['IiOiLeftQty'],1,0,'C',$fill);
			$this->Cell($headerwidth[5],6,$row['IiOiRightQty'],1,0,'C',$fill);
			$this->Cell($headerwidth[6],6,$row['OiTotalQty'],1,0,'C',$fill);
			$this->Cell($headerwidth[7],6,$row['OiPrice'],1,0,'C',$fill);
			$this->Cell($headerwidth[8],6,$amount,1,0,'C',$fill);
			$this->SetFontSize(10);
			$this->Ln();
			$totalAmount += $amount; //$amount is amount for each item. added on to totalAmount for sum.
	        $fill = !$fill;
			$rc += 1;
	    }
		$this->Ln();
		$this->Cell(95);
		$this->Cell(45,6,"Total Amount (AED): ",'LTRB',0,'R',$fill);
		$this->Cell(30,6,number_format($totalAmount, 2, '.', ''),'LTRB',0,'R',$fill);
	    // Closing line
	    //$this->Cell(array_sum($headerwidth),0,'','T');
	}
}
class Orders extends CI_Controller
{
	public function index()
	{
		// Loads up order list
		// $this->load->model('order_model');
		// $data['orders'] = $this->order_model->get_orders();
		$data['title'] = ucfirst("orders");
		$data['jslist']=array('orderslist.js');
		// $data['autorefresh']=TRUE;
		// $data['baseurl']=base_url();
		$this->load->view('templates/header', $data);
		$this->load->view('pages/orderslist');
		$this->load->view('templates/footer');
	}
	public function get_orderlist()
	{

		$this->load->model('order_model');
		$data['orders'] = $this->order_model->get_orders();
		echo json_encode($data['orders']);

	}

	public function get_order_details($omid,$print = "FALSE")
	{

		$this->load->model('order_model');
		$data['orderinfo'] = $this->order_model->get_orders($omid);
		$data['items'] = $this->order_model->get_order($omid);
		$data['title'] = ($print == "FALSE")? ucfirst("order Details") : ucfirst("Order Print");
		$jslist =array(($print == "FALSE")? "order_details.js" : "order_print.js");
		$data['jslist'] = $jslist;
		$data['autorefresh']=FALSE;

		$this->load->view('templates/header', $data);
		if($print == "FALSE")
		{
			$this->load->view('pages/order');
		}
		else
		{
			$this->load->view('pages/order_print');
		}
		$this->load->view('templates/footer');
	}
	public function create_new_order()
	{
		$this->load->model('client_model');
		$data['clients'] = $this->client_model->get_clients();
		$data['title'] = ucfirst("new Order");
		$data['mode'] = 'New';

		$jslist = array("custom_functions.js","neworder.js");
		$data['jslist'] = $jslist;
		//$data['clients'] =
		$data['autorefresh']=FALSE;
		$this->load->view('templates/header',$data);
		$this->load->view('pages/v_new_sales_order');
		$this->load->view('templates/footer');
	}
	public function save_order()
	{
		// Load models.
		$this->load->model('order_model');
		$this->load->model('user_model');
		// save post username to variable
		$usrname = $this->input->post('username');
		// get the userid from username
		$usrid = $this->user_model->get_userid($usrname);
		// if username not found. (only case to heppen: someone messed with the data)
		// if($usrid == false)
		// {
		// 	die(header("HTTP/1.0 404 Not Found"));
		// }
		// else send userid to post order and get result.
		$result = $this->order_model->post_order($usrid['UsrId']);
		// if($result)
		// {
		// 	header('HTTP/1.1 404 Item Not Found');
  //       	header('Content-Type: application/json; charset=UTF-8');
  //       	die(json_encode(array('message' => 'ERROR', 'code' => 404)));
		// }
		echo json_encode($result);
	}
	// Edit order
	// /Edit order

	// Delete order
	public function delete_order()
	{
		$usrLvl = $this->input->post('usrlvl');
		if($usrLvl<7)
		{
			header('HTTP/1.1 466 Unauthorized User');
			header('Content-Type: application/json; charset=UTF-8');
			die(json_encode(array('message' => 'ERROR', 'code' => 466)));
		}
		$this->load->model('order_model');
		$result = $this->order_model->delete_order();
		echo json_encode($result);
	}
	// /Delete Order
	public function print_order($orderNumber=0)
	{
		$this->load->model('order_model');
		$oinfo= $this->order_model->get_invoices($orderNumber);
		$items= $this->order_model->get_invoice_items($orderNumber);
		// Cell(float w [, float h [, string txt [, mixed border [, int ln [, string align [, boolean fill [, mixed link]]]]]]])


		$pdf = new PDF();
		$pdf->setRows($oinfo);
		$pdf->AddPage();
		$pdf->FancyTable($items);
		//$pdf->Output();
		$pdf->Output('F','e:/Documents/Carryon/OnSysOrders/I-'.$orderNumber.'.pdf');
		// echo ('Order saved :'.$orderNumber);

	}


	public function order_item_state()
	{
		$this->load->model('order_model');
		$date = new DateTime();
		$state=array(
			'OiId' => $this->input->post('oiid'),
			'OiOmId' => $this->input->post('oiomid'),
			'OiModifiedOn' => $date->getTimestamp(),
			'OiStatus' => $this->input->post('status')
		);
		if($this->input->post('oitotalqty') != NULL)
		{
			// Create additional Array
			$state_addition = array(
				'OiLeftQty' => $this->input->post('oileftqty'),
				'OiRightQty' => $this->input->post('oirightqty'),
				'OiTotalQty' => $this->input->post('oitotalqty')
			);
			// Merge it with Existing $state array
			$state = array_merge($state,$state_addition);
		}
		$result = $this->order_model->order_item_state($state);
		echo json_encode($state);
	}
	public function set_store_state()
	{
		$this->load->model('order_model');
		$result = $this->order_model->set_store_state();
		echo json_encode($result);
	}
	public function set_print_state()
	{
		$this->load->model('order_model');
		$orderid = $this->input->post('orderid');
		$result = $this->order_model->set_print_state($orderid);
		// print_order($orderid);
		$this->print_order($orderid);
		echo json_encode($result);
	}


	//BETA version of CRUD system. version 2.0 if you will.
	private function validate_user($user_lvl, $allowed_lvl) {
		//return true if allowed_lvl >= $user_lvl
		if($user_lvl >= $allowed_lvl) {
			return TRUE;
		}
		else {
			return FALSE;
		}
	}
	public function crud_sales_order($state, $order_id="") {
		// 1.check what the state is.
		// 2.after that check if user lvl is allowed to execute state.
		// 3.check if its a valid order id and that its not being edited by someone else.
		echo $state;
		$user_lvl = $this->session->level;
		if($state == "New") {
			if($this->validate_user($user_lvl, 6) == TRUE) {
				//do the new order things.
				$this->load->model('client_model');
				$data['clients'] = $this->client_model->get_clients();
				$data['title'] = ucfirst("New Order");
				$data['mode'] = $state; //this will be "New"
				$data['jslist'] = array('custom_functions.js','neworder.js');
				//$data['clients'] =
				$data['autorefresh']=FALSE;
				$this->load->view('templates/header',$data);
				$this->load->view('pages/v_new_sales_order');
				$this->load->view('templates/footer');
			}
		}
		elseif ($state == "Edit") {
			//load only for level 7 user or higher
			echo $order_id;
			if ($this->validate_user($user_lvl,6) == TRUE) {
				//load order_model
				$this->load->model('order_model');
				$data['orderinfo'] = $this->order_model->get_orders($order_id);
				$data['items'] = $this->order_model->get_order($order_id);
				$data['title'] = "Order Edit";
				$data['mode'] = $state;
				$jslist =array('custom_functions.js','editorder.js');
				$data['jslist'] = $jslist;
				$data['autorefresh']=FALSE;
				echo $order_id;
				$this->load->view('templates/header', $data);
				$this->load->view('pages/v_new_sales_order');
				$this->load->view('templates/footer');
			}

		}
		elseif ($state == "Delete") {
			# code...

		}
		else {
			# code...
			// show 404 error.
		}
	}
	public function make_invoice()
	{
		
		//first i need to get the order_id and do the invoice making process, 
		$this->load->model('order_model');
		//then actually make/create invoice from order_id and return Invoice number
		$invNo = $this->order_model->make_invoice();
		$oinfo= $this->order_model->get_invoices($invNo);
		$items= $this->order_model->get_invoice_items($invNo);
		
		$pdf = new PDF();
		$pdf->setRows($oinfo);
		$pdf->AddPage();
		$pdf->FancyTable($items);
		//$pdf->Output();
		$pdf->Output('F','e:/Documents/Carryon/OnSysOrders/I-'.$orderNumber.'.pdf');
		
		// Cell(float w [, float h [, string txt [, mixed border [, int ln [, string align [, boolean fill [, mixed link]]]]]]])
		// $pdf = new PDF('P','mm','A4');
		// $pdf->setRows($oinfo);
		// $pdf->AddPage();
		// $pdf->SetFont('Arial','B',16);
		// $pdf->Cell(40,10,'Hello World!');
		// //$pdf->FancyTable($items);
		// //$pdf->Output();
		// $pdf->Output();
	}
	public function print_invoice($inv_id=0)
	{
		$this->load->model('order_model');
		$oinfo= $this->order_model->get_invoices($inv_id);
		$items= $this->order_model->get_invoice_items($inv_id);
		// Cell(float w [, float h [, string txt [, mixed border [, int ln [, string align [, boolean fill [, mixed link]]]]]]])


		$pdf = new PDF();
		$pdf->setRows($oinfo);
		$pdf->AddPage();
		$pdf->FancyTable($items);
		//$pdf->Output();
		$pdf->Output('F','e:/Documents/Carryon/OnSysOrders/I-'.$orderNumber.'.pdf');
		// echo ('Order saved :'.$orderNumber);

	}

}
